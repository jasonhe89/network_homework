client.py is for Persistent HTTP with 1 connection
non-client.py is for Non-persistent HTTP with 1 connection
non-pclient.py  is for Non-persistent HTTP with 5 parallel connections
pclient.py is for Persistent HTTP with 5 parallel connections
pServer.py is for HTTP server.

The client program will fetch the index.html and download all the img files. 
